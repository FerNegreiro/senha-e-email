# Definindo os valores de email e senha cadastrados antecipadamente
email_cadastrado = "usuario@email.com"
senha_cadastrada = "senha123"

# Solicitando ao usuário email e senha e verificando se correspondem aos valores cadastrados
while True:
    email_usuario = input("Digite o seu email: ")
    senha_usuario = input("Digite a sua senha: ")

    if email_usuario == email_cadastrado and senha_usuario == senha_cadastrada:
        print("Login realizado com sucesso!")
        break
    else:
        print("Email ou senha incorretos. Por favor, tente novamente.")
